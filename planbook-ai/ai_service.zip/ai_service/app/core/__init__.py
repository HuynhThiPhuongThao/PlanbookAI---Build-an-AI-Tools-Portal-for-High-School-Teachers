"""Core configuration package."""

