from collections.abc import Generator

from sqlalchemy.orm import Session

from ai_service.app.database import SessionLocal


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

