"""Pydantic schemas package."""

